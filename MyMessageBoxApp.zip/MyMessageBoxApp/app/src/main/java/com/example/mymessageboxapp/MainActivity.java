package com.example.mymessageboxapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText editTextMessage = findViewById(R.id.editTextMessage);
        Button buttonInfo = findViewById(R.id.buttonInfo);
        Button buttonAlert = findViewById(R.id.buttonAlert);
        Button buttonDatePicker = findViewById(R.id.buttonDatePicker);
        Button buttonTimePicker = findViewById(R.id.buttonTimePicker);

        //delegete method calls
        buttonInfo.setOnClickListener(v ->
                showAlertDialogue("Information",editTextMessage.getText().toString()));
        buttonAlert.setOnClickListener(v ->
                showAlertDialogue("Alert",editTextMessage.getText().toString()));
        buttonDatePicker.setOnClickListener(v -> showDatePickerDialog());
        buttonTimePicker.setOnClickListener(v -> showTimePickerDialog());
    }
    private void showAlertDialogue(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK",((dialog, which) -> dialog.dismiss()));
        AlertDialog dialog =builder.create();
        dialog.show();

    }
    private void showDatePickerDialog() {
// use the Java.util gradle library
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    showAlertDialogue("Selected Date", date);
                }, year, month, day);

        datePickerDialog.show();
    }
    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, selectedHour, selectedMinute) -> {
                    String time = selectedHour + ":" + selectedMinute;
                    showAlertDialogue("Selected Time", time);
                }, hour, minute, true);

        timePickerDialog.show();
    }
}