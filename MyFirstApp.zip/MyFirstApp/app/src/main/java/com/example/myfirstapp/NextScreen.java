package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class NextScreen extends AppCompatActivity {

    Button back_btn;

    TextView tvFinal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_screen);

        back_btn = (Button)findViewById(R.id.back_btn);
        tvFinal= (TextView)findViewById(R.id.tv_final);
        Intent intent = getIntent();
        String text = intent.getStringExtra(MainActivity.RESULT_TEXT);
        tvFinal.setText("The final number is " + text);


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackScreenClick(view);
            }
        });
    }
    public void onBackScreenClick(View view){
        super.onBackPressed();
    }
}