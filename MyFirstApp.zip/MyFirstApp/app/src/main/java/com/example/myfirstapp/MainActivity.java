package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
//these bring in the API's
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final  String RESULT_TEXT ="com.example.myfirstapp.RESULT_TEXT";
    //create UI object reference ID's
    Button AddButton;
    TextView ResultTV;
    Button MinusButton;
    Button NextScreenButton;
    int num =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //register our Objects with our UI ID's
        AddButton = (Button) findViewById(R.id.my_btn_add);
        ResultTV = (TextView) findViewById(R.id.my_tv_total);
        MinusButton = (Button)findViewById(R.id.my_btn_minus);
        NextScreenButton = (Button) findViewById(R.id.my_btn_nextscreen);

        //create button events
        //listener--waits for something to be triggered(listening for events)
        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num++;
                ResultTV.setText(String.valueOf(num));
            }
        });

        MinusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num--;
                ResultTV.setText(String.valueOf(num));
            }
        });
        NextScreenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OnNextScreenClick(view);
            }
        });
    }
    public void OnNextScreenClick(View view){
        String result = ResultTV.getText().toString();

        Intent i =new Intent(this,NextScreen.class);
        //bundling of extra info that will pass through pges/activities
        i.putExtra(RESULT_TEXT,result);
        startActivity(i);
    }
}